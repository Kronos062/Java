abstract class Figura2D implements FiguraGeometrica {
    String nombre;

    Figura2D(String nombre) {
        this.nombre = nombre;
    }
}
