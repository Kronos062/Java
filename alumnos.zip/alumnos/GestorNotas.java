public class GestorNotas {
    String nombreAlumno;
    double[] notas;

    public GestorNotas(String nombreAlumno, double[] notas) {
        this.nombreAlumno = nombreAlumno;
        this.notas = notas;
    }

    public static void registrarNotas(String nombreAlumno, double[] notas) {
        notasAlumnos(nombreAlumno, notas);
    }

    public static double[] obtenerNotas(String nombreAlumno) {
        return notasAlumnos(nombreAlumno);
    }
}

