public class Main {
    public static void main(String[] args) {
        double[] notasAlumno1 = {3.33, 7.7, 3.14};
        double[] notasAlumno2 = {8.81, 7.7, 9.24};

	GestorNotas gestor = new GestorNotas();

        gestor.registrarNotas("Alumno1", notasAlumno1);
        gestor.registrarNotas("Alumno2", notasAlumno2);

        double[] notasObtenidas = gestor.obtenerNotas("Alumno1");
        System.out.println("Notas de l'Alumno1: ");
        for (double nota : notasObtenidas) {
            System.out.println(nota);
        }

        CalculadoraEstadisticas calculadora = new CalculadoraEstadisticas();
        double mediana = calculadora.calcularMediana(notasObtenidas);
        double maximo = calculadora.calcularMaximo(notasObtenidas);
        double minimo = calculadora.calcularMinimo(notasObtenidas);

        System.out.println("Mediana: " + mediana);
        System.out.println("Nota màxima: " + maximo);
        System.out.println("Nota mínima: " + minimo);
    }
}

